import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';

@Component({
  selector: 'app-usuario',
  imports: [FormsModule, CommonModule],
  templateUrl: './usuario.component.html',
  styleUrl: './usuario.component.css'
})
export class UsuarioComponent {
  nombre: string = 'Juan';
  edad: number = 25;
  nombreCapitalizado: string = this.nombre;

  mostrarModal: boolean = false;
  tipoModal: 'nombre' | 'edad' | 'reset' | '' = '';

  nuevoNombre: string = '';
  nuevaEdad: number | null = null;
  nuevoNombreCapitalizado: string = '';

  abrirModal(tipo: 'nombre' | 'edad' | 'reset') {
    this.tipoModal = tipo;
    this.mostrarModal = true;
  }

  cerrarModal() {
    this.mostrarModal = false;
    this.tipoModal = '';
    this.nuevoNombre = '';
    this.nuevaEdad = null;
    this.nuevoNombreCapitalizado = '';
  }

  guardar() {
    if (this.tipoModal === 'nombre' && this.nuevoNombre.trim() !== '') {
      this.nombre = this.nuevoNombre;
      this.nombreCapitalizado = this.nuevoNombre.toUpperCase();
    }

    if (this.tipoModal === 'edad' && this.nuevaEdad !== null) {
      this.edad = this.nuevaEdad;
    }

    if (this.tipoModal === 'reset' && this.nuevoNombreCapitalizado.trim() !== '') {
      this.nombreCapitalizado = this.nuevoNombreCapitalizado;
    }

    this.cerrarModal();
  }

}
